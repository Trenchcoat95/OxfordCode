which mklib.sh

mklib.sh GasUtils
mklib.sh gasElement
mklib.sh gasMixer
